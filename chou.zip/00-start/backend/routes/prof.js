const router = require('express').Router();
let prof= require('../models/prof.model');

router.route('/').get((req, res) => {
  prof.find()
    .then(felieres => res.json(felieres))
    .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/add').post((req, res) => {
 
  const felierename = req.body.felierename;
  const description = req.body.description;
  const capacity = Number(req.body.capacity);
  const date = Date.parse(req.body.date);

  const newExercise = new prof({
  
    felierename,
    description,
    capacity,
    date,
  });

  newExercise.save()
  .then(() => res.json('Exercise added!'))
  .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/:id').get((req, res) => {
  prof.findById(req.params.id)
    .then(feliere => res.json(feliere))
    .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/:id').delete((req, res) => {
  prof.findByIdAndDelete(req.params.id)
    .then(() => res.json('Exercise deleted.'))
    .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/update/:id').post((req, res) => {
 prof.findById(req.params.id)
    .then(feliere => {
      feliere.username = req.body.username;
      feliere.felierename = req.body.felierename;
      feliere.description = req.body.description;
      feliere.capacity = Number(req.body.capacity);
      feliere.date = Date.parse(req.body.date);

      prof.save()
        .then(() => res.json('Exercise updated!'))
        .catch(err => res.status(400).json('Error: ' + err));
    })
    .catch(err => res.status(400).json('Error: ' + err));
});

module.exports = router;