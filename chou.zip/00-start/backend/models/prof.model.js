const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const profSchema = new Schema({
  matierename: { type: String, required: true },
  felierename: { type: String, required: true },
  description: { type: String, required: true },
  capacity: { type: Number, required: true },
  date: { type: Date, required: true },
}, {
  timestamps: true,
});

const professeur = mongoose.model('prof', profSchema);

module.exports = professeur;