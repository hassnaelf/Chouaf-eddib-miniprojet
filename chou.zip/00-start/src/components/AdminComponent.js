import React from 'react';
import home from './home.js'
import hom from './home2.js'

import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Route} from "react-router-dom";

import Navbar from "./components/navbar.component"
import ExercisesList from "./components/exercises-list.component";
import EditExercise from "./components/edit-exercise.component";
import CreateExercise from "./components/create-exercise.component";
import CreateUser from "./components/create-user.component";
import Gestionfeliere from './gestionfeliere.js';
import Gestionprof from './gestionprof.js';
import GestionEtudiant from './gestionEtudiant.js';
import   login   from './components/loginComponent/Login.js';




function AdminComponent() {
  return (
    <Router>
      <div className="container">
     
      <br/>

      <Route path="/" exact component={home} />
      
      <Route path="/admin" exact component={hom} />
      <Route path="/gestionfeliere" exact component={Gestionfeliere} />
      <Route path="/gestionprof" exact component={Gestionprof} />
      <Route path="/gestionetudiant" exact component={GestionEtudiant } />
      </div>
    </Router>
  );
}

export default AdminComponent;