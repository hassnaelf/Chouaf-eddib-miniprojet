import React, { Component } from 'react';
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

export default class Login extends Component {
	constructor(props) {
		super(props);

		this.state = {
			user_name: '',
			password: '',
			
		}
	}

	handleOnChangeUserName = (e) =>  {
		this.setState({
			user_name: e.target.value
		});
	}

	handleOnChangePassword = (e) => {
		this.setState({
			password: e.target.value
		});
	}

	onSubmit =  e => {
		
		const   username= this.state.user_name
		const password= this.state.password
		if(username=="admin"   &&  password==123)
        window.location = '/home';
		
	}

	render() {
		
		return (
			 <div className="Login">
				
				<form onSubmit={this.onSubmit}>
					<div>
						<div className="fields">
				
							<input type="text" name="Username" onChange={this.handleOnChangeUserName} autoComplete="Username" required/>
						</div>
						<div className="fields">
							
							<input type="password" name="Password" onChange={this.handleOnChangePassword} autoComplete="Password" required/></div>
						<div className="buttons">
							<button type="button" onClick={this.onSubmit} className="btn btn-primary"></button>
							<Link to="/register"></Link>
						</div>
					</div>
				</form>
				{ }
				</div>
			);
		}
}


