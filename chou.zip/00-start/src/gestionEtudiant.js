import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Route,Switch} from "react-router-dom";
import React ,{Component} from 'react';
import NavBarEtudiant from "./components/gestionEtudiant/NavBarEtudiant.js";
import  FormulaaireInscription  from  "./components/gestionEtudiant/FormulaaireInscription.js";
import List from './components/gestionEtudiant/Liste_Etudiant.js'
import  EtudiantList  from  "./components/gestionEtudiant/Liste_Etudiant.js";
class GestionEtudiant extends Component{
    render(){
        
  return (

    <Router>
      <div className="container">
     
    
      <NavBarEtudiant />
    
      <Route path="/gestionetudiant" exact component={List} />
    
      <Route path="/gestionetudiant/create" exact component={FormulaaireInscription} />
    
     
     
   
      
      </div>
    </Router>
      
  );
    }


}

export default GestionEtudiant;