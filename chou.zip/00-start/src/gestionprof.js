import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Route} from "react-router-dom";
import React ,{Component} from 'react';
import Navbar from "./components/gestionprof/navbar.component"
import profList from "./components/gestionprof/prof-list";
import Editprof from "./components/gestionprof/modifierprof";
import Createprof from "./components/gestionprof/ajouterprof";
import Creatematiere from "./components/gestionprof/ajoutermatiere";


class Gestionprof extends Component{
    render(){
        
  return (
    <Router>
      <div className="container">
      <Navbar />
      <br/>
      <Route path="/gestionprof" exact component={profList} />
      
      <Route path="/gestionprof/edit/:id" component={Editprof} />
      <Route path="/gestionprof/create" component={Createprof} />
      <Route path="/gestionprof/user" component={Creatematiere} />
      
      
      </div>
    </Router>
  );
    }


}

export default Gestionprof;