import React, { Component } from "react";

import 'bootstrap/dist/css/bootstrap.css';

import './nav.css'
import gestionfeliere from './gestionfeliere.js'

class Navbar extends React.Component {
  render() {
    return (

        
          <div>
          <nav class="navbar navbar-expand-md navbar-dark bg-dark sticky-top">
         
         <button class="navbar-toggler" data-toggle="collapse" data-target="#menuhamburger">
             <span class="navbar-toggler-icon"></span>
            </button>
         <div class="collapse navbar-collapse" id="menuhamburger">
           <ul class="navbar-nav m-auto">
             <li class="nav-item active">
            <a href="/" class="navbar-brand" >ESTE</a>
             
             </li>
             
             <li class="nav-item">
               <a href="/gestionetudiant" class="nav-link">gestion des Etudiant</a>
             </li>
             <li class="nav-item">
               <a href="/gestionfeliere" class="nav-link">gestion Feliere</a>
             </li>
             <li class="nav-item">
               <a href="/gestionprof" class="nav-link">gestion proffesseur</a>
             </li>
             
            
           </ul>
      
           
         </div>
     </nav>
           </div>

);
}
}
export default Navbar;

