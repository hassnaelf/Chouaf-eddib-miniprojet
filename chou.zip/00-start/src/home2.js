import React,{Component} from 'react'
import VNAV from './nav2.js'






 class Home2 extends Component
 {
     
     render()
     {
         return(
             <div>
              <VNAV/>  
               
            </div>
            

         )
     }
 }
 export default  Home2;