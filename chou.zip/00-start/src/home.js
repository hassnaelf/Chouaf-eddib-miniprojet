import React,{Component} from 'react'
import './home.css';
import image from './scd2019.jpg'
import Navbar from './nav.js';
import image1 from './ss_2019.jpg';
import Footer from './footer.js';

import yy from './tudiant-854x538.jpg'
 class Home extends Component
 {
     
     render()
     {
         return(
             <div>
                 <Navbar/>
                 <div>

                 <div class="overlay-image"><a href="URL_LIEN">
 <img class="image" src={yy} alt="Alt text" />
 <div class="normal">
  <div class="text">Bienvenue
  </div>
 </div>
 <div class="hover">
  <div class="text">Bienvenue
   EST ESSAOUIRA
   
   </div>
 </div>
</a></div>
                 </div>

            
              
           
             
           
           
            
           
            </div>
           
            

         )
     }
 }
 export default  Home;